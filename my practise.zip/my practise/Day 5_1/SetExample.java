package day5;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {
	
	public static void main(String[] args) {
		
		// InterfaceName variableName = new ClassType();
		
		
		Set<Integer> s = new TreeSet();
		
		s.add(10);
		s.add(20);
		s.add(30);
		s.add(50);
		s.add(40);
		s.add(5);
		
		
		
		System.out.println(s);
		
		
		int i = s.size();
		System.out.println(i);
		
		s.remove(20);
		System.out.println(s);
		
		
		boolean b = s.isEmpty();
		System.out.println(b);
		
		
		boolean c = s.contains(30);
		System.out.println(c);
		
	for (Integer l : s) {
		System.out.println(l);
		
	}
		
		List<Integer> li = new LinkedList<>(s);
		
		System.out.println("list value - " +li);
		
		
		
		for (int j = 1; j < li.size(); j++) {
			Integer h = li.get(j);
			System.out.println(h);
			
		}
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
