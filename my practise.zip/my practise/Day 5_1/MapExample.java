package day5;

import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapExample {

	public static void main(String[] args) {


		Map<Integer, String> mp = new Hashtable();
		mp.put(10, "JAVA");
		mp.put(20, "Python");
		mp.put(30, "Selenium");
		mp.put(40, "Ruby");


		System.out.println(mp);


		// to find the sizeof the map

		int size = mp.size();
		System.out.println(size);


		// to get all the key from map

		Set<Integer> keySet = mp.keySet();
		System.out.println(keySet);


		// to get all the values from map

		Collection<String> values = mp.values();
		System.out.println(values);




		// to check whether the key ispresent or not


		boolean b = mp.containsKey(10);
		System.out.println(b);


		// to check whether the value is present

		boolean c = mp.containsValue("JAVA");
		System.out.println(c);


		// to remove the values using key


		mp.remove(30);
		
		System.out.println(mp);
		
		
		// to get the particular value from map using key
		
		String x = mp.get(40);
		System.out.println(x);
		
		
		Set<Entry<Integer,String>> entrySet = mp.entrySet();
		System.out.println(entrySet);
		
		for (Entry<Integer, String> entry : entrySet) {
			System.out.println(entry);
			
		}
		
		
List<Integer> li = new LinkedList(entrySet);
		
		System.out.println("list value - " +li);
		
		
		
		



	}

}
