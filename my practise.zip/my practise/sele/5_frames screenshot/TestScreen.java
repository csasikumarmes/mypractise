package org.test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestScreen {
	
	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("Webdriver.chrome.driver", 
				"C:\\Users\\sasik\\Ayush\\TestSelenium\\driver\\chromedriver.exe");
		// WebDriver - interface, ChromeDriver - Class

		WebDriver driver = new ChromeDriver();
		driver.get("https://netbanking.hdfcbank.com/netbanking/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		WebElement element = driver.findElement(By.xpath("//frame[@name='login_page']"));
		driver.switchTo().frame(element);
		
		driver.findElement(By.name("fldLoginUserId")).sendKeys("1234567");
		
		Thread.sleep(4000);
		
		TakesScreenshot as = (TakesScreenshot)driver;
		File s = as.getScreenshotAs(OutputType.FILE);
		
		
		File d = new File("C:\\Users\\sasik\\OneDrive\\Pictures\\Screenshots\\123.jpg");
		
		FileUtils.copyFile(s, d);
		
		driver.quit();
		
	}

}
