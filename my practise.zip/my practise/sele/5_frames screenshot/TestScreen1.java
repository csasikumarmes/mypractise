package org.test;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestScreen {
	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\sasik\\susant\\TestTest\\driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		WebElement element = driver.findElement(By.xpath("//select[@id='country']"));

		Select s = new Select(element);
		List<WebElement> options = s.getOptions();
		
		for (int i = 1; i < options.size(); i++) {
			WebElement element2 = options.get(i);
			String text = element2.getText();
			System.out.println(text);
			
		}
		
		
		
		s.selectByIndex(2);
		Thread.sleep(2000);
		
		
		TakesScreenshot scr = (TakesScreenshot)driver;
		
		File f = scr.getScreenshotAs(OutputType.FILE);
		
		
		
		File d = new File("C:\\Users\\sasik\\OneDrive\\Pictures\\Screenshots\\susant.jpg");
		
		FileUtils.copyFile(f, d);
		
		
		driver.quit();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

}
	
}



