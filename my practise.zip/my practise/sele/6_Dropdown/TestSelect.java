package org.test;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestSelect {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\sasik\\susant\\TestTest\\driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		WebElement element = driver.findElement(By.xpath("//select[@id='Skills']"));
		
		Select s = new Select(element);
		List<WebElement> options = s.getOptions();
		
		for (int i = 1; i < options.size(); i++) {
			WebElement element2 = options.get(i);
			String text = element2.getText();
			System.out.println(text);
			
		}
		
		
		
		s.selectByIndex(2);
		Thread.sleep(2000);
		
		WebElement year = driver.findElement(By.xpath("//select[@id='yearbox']"));
		
		Select s2 = new Select(year);
		s2.selectByValue("2005");
		
Thread.sleep(2000);
		
		WebElement month = driver.findElement(By.xpath("//select[@placeholder='Month']"));
		

		Select s3 = new Select(month);
		s3.selectByVisibleText("January");
		
		
		
		
	}

}
