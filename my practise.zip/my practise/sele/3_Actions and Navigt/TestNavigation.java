package org.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestNavigation {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\sasik\\susant\\TestTest\\driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.amazon.in/");
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		driver.navigate().to("https://www.flipkart.com/");
		
		Thread.sleep(2000);
		
		
		driver.navigate().back();
		
		Thread.sleep(2000);
		
		driver.navigate().forward();
		
		
		Thread.sleep(4000);
		
		driver.navigate().refresh();
		
		Thread.sleep(2000);
		
		driver.quit();
		
		
		
		
		
		
		
	}

}
