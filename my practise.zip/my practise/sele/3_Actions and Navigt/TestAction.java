package org.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TestAction {
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\sasik\\susant\\TestTest\\driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		
		
		WebElement element1 = driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
		
		Actions act = new Actions(driver);
		
		act.moveToElement(element1).perform();
		
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//span[contains(text(),'Create a Wish')]")).click();
	
		
		
	}

}
