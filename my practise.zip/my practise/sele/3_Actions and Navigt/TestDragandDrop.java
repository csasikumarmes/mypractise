package org.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TestDragandDrop {
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\sasik\\susant\\TestTest\\driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.guru99.com/test/drag_drop.html");
		driver.manage().window().maximize();
		
		WebElement s = driver.findElement(By.xpath("//a[contains(text(),'SALES')]"));
		
		
		WebElement d = driver.findElement(By.xpath("//ol[@id='loan']"));
		
		Actions act = new Actions(driver);
		
		act.dragAndDrop(s, d).perform();
		
		Thread.sleep(4000);
		driver.quit();
	}

}
