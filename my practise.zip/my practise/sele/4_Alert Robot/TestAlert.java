package org.test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestAlert {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\sasik\\susant\\TestTest\\driver\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://letcode.in/alert");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		WebElement element = driver.findElement(By.xpath("//button[contains(text(),'Simple Alert')]"));
		
		element.click();
		Thread.sleep(3000);
		
		Alert a = driver.switchTo().alert();
		
//		a.sendKeys("Sasikumar");
		
		String text = a.getText();
		System.out.println(text);
		Thread.sleep(3000);
		a.accept();
		driver.quit();
		
		
	}

}
