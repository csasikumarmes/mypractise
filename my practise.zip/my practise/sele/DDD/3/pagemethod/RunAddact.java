package org.test.pagemethod;

import org.base.BaseClass;

public class RunAddact {
	
	public static void main(String[] args) throws Exception {
		
		
		
		AddactPagemethod.Login(BaseClass.excelRead(1, 1), BaseClass.excelRead(1, 2));
		AddactPagemethod.searchHotel();
		
		
		
	}

}
