package org.test.pagemethod;

import org.base.BaseClass;

public class AddactPagemethod extends BaseClass {
	
	public static void Login(String username, String psw) throws Exception {
		urlLaunch(excelRead(1, 0));
		maximize();
		Thread.sleep(4000);
		findElement("//input[@id='username']");
		sendkey(username);
		Thread.sleep(2000);
		findElement("//input[@id='password']");
		sendkey(psw);
		Thread.sleep(2000);
		findElement("//input[@id='login']");
		click();
	}
	
	
	public static void searchHotel() throws Exception {
		findElement("//select[@id='location']");
		selectvisibleText(excelRead(1, 3));
		Thread.sleep(2000);
		
		
		findElement("//select[@id='hotels']");
		selectvisibleText(excelRead(1, 4));
		Thread.sleep(2000);
		
		findElement("//select[@id='room_type']");
		selectvisibleText(excelRead(1, 5));
		Thread.sleep(2000);
		
		findElement("//select[@id='room_nos']");
		selectvisibleText(excelRead(1, 6));
		Thread.sleep(2000);
		
		findElement("//input[@id='datepick_in']");
		clear();
		sendkey(excelRead(1, 7));

		findElement("//input[@id='datepick_out']");
		clear();
		sendkey(excelRead(1, 8));
		Thread.sleep(2000);

		findElement("//select[@id='adult_room']");
		selectvisibleText(excelRead(1, 9));
		Thread.sleep(2000);
		
		findElement("//input[@id='Submit']");
		click();
		Thread.sleep(2000);
	}
	
	public static void main(String[] args) throws Exception {
//		Login();
		searchHotel();
	}

}
