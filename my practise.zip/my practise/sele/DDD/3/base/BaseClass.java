package org.base;

import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.text.SimpleDateFormat;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public static WebDriver driver;
	public static WebElement element;
	static String value;

	
	
	public static void urlLaunch(String url) {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get(url);
	}

	public static void maximize() {
		driver.manage().window().maximize();

	}
	
	public static void findElement(String xpath) {
		element = driver.findElement(By.xpath(xpath));

	}
	
	public static void sendkey(String text) {
		element.sendKeys(text);

	}
	
	
	public static void click() {
		element.click();
	}

	
	public static void selectvisibleText(String text) {
		
		Select sl = new Select(element);
		sl.selectByVisibleText(text);
		
	}
	
	
	public static void clear() {
		element.clear();

	}





	public static String excelRead(int rowNo, int cellNo) throws Exception {

		
		File f = new File("C:\\Users\\sasik\\susant\\TestMaven\\data\\Addact.xlsx");

		FileInputStream fi = new FileInputStream(f);

		Workbook wb = new XSSFWorkbook(fi);

		Sheet sh = wb.getSheet("Sheet1");

		Row r = sh.getRow(rowNo);

		Cell c = r.getCell(cellNo);

		int cellType = c.getCellType();

		// type  =0 - integer
		// type =1 - string

		if (cellType==1) {

			value = c.getStringCellValue();

		}

		if (cellType==0) {

			if (DateUtil.isCellDateFormatted(c)) 
			{
				Date date = c.getDateCellValue();
				SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");
				value = dateformat.format(date);
			}

			else {
				double d = c.getNumericCellValue();
				long l = (long)d;
				value = String.valueOf(l);
			}

		}

		//		
		//		int numberOfRows = sh.getPhysicalNumberOfRows();
		//
		//		System.out.println(numberOfRows);
		//		
		//		int numberOfCells = r.getPhysicalNumberOfCells();
		//
		//		System.out.println("Number of cells -"+numberOfCells);
		return value;

	}

}
