package org.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Addact {
	
	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://adactinhotelapp.com/");
		
		Thread.sleep(4000);
		
		File f = new File("C:\\Users\\sasik\\susant\\TestMaven\\data\\Addact.xlsx");
		
		FileInputStream fi = new FileInputStream(f);
		
		Workbook wb = new XSSFWorkbook(fi);
		
		Sheet sh = wb.getSheet("Sheet1");
		
		Row r = sh.getRow(1);
		
		Cell c = r.getCell(1);
		
		String username = c.getStringCellValue();
		
		Cell c1 = r.getCell(2);
		String psw = c1.getStringCellValue();
		
			
				
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
		
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(psw);
		
		
		
	}

}
