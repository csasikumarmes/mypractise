package org.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Addact extends BaseClass{
	
	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://adactinhotelapp.com/");
		
		Thread.sleep(4000);
		
		String username = excelRead(1, 1);
		String psw = excelRead(1, 2);
		String location = excelRead(1, 3);
		String date_in = excelRead(1, 4);
		
		
		
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(psw);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='login']")).click();
		Thread.sleep(2000);
		
		WebElement element = driver.findElement(By.xpath("//select[@id='location']"));
		Select sl = new Select(element);
		
		
		sl.selectByVisibleText(location);
		Thread.sleep(2000);
		
		
		WebElement element2 = driver.findElement(By.xpath("//input[@id='datepick_in']"));
		element2.clear();
		Thread.sleep(2000);
		element2.sendKeys(date_in);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
