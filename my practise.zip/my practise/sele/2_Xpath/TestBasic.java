package org.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBasic {
	public static void main(String[] args) {
		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\sasik\\susant\\TestTest\\driver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		
		// to maximize the screen
		driver.manage().window().maximize();
		
		
		// to get the tittle 
		
		
		String title = driver.getTitle();
		
		System.out.println(title);
		
		
		// to get the current url
		
		
		String currentUrl = driver.getCurrentUrl();
		System.out.println(currentUrl);
		
//		
//		WebElement element = driver.findElement(By.xpath("//*[@id='email']"));
//		
//		element.sendKeys("sasikumar");
//		
//		WebElement element2 = driver.findElement(By.id("pass"));
//		element2.sendKeys("123456");
//		
//		
//		WebElement element3 = driver.findElement(By.name("login"));
//		
//		element3.click();
		
		
//		WebElement element4 = driver.findElement(By.xpath("//a[text()='Create new account']"));
//		element4.click();
		
//		WebElement element5 = driver.findElement(By.xpath("//a[contains(text(),'Create')]"));
//		element5.click();
//		
		
		
		// basec o index
		
//		WebElement element6 = driver.findElement(By.xpath("(//a[contains(text(),'Create')])[2]"));
//		element6.click();
		
		
		
		// two attribute
		
		WebElement element6 = driver.findElement(By.xpath("//input[@id='email'][@name='email']"));
		element6.sendKeys("sasi");
		
		
		// to close the browser
		
//		driver.quit();
	}

}
