package org.exp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestException {
	public static void main(String[] args) {
		System.out.println(4/2);


		try {
			try {
				WebDriverManager.chromedriver().setup();
				WebDriver driver = new ChromeDriver();
				driver.get("https://www.facebook.com/");
			} catch (Exception e) {
				System.out.println("Session Not Created");
			}
			finally {
				System.out.println("Inner Final Block");
			}

		} catch (Exception e) {
			System.out.println("Outer Catch");
		}
		finally {
			System.out.println("Exception Handled");
		}



	}

}
