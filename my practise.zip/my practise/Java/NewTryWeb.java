package org.test.webtable;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewTryWeb {
	WebElement table;
	WebDriver driver;
	
	
	@Test
	public void webTable() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://letcode.in/table");
		driver.manage().window().maximize();
		
		Date d = new Date();
		System.out.println(d);
		
		try {
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			
			table = driver.findElement(By.id("simpletable"));
			Date d1 = new Date();
			System.out.println(d1);
			
		} catch (NoSuchElementException e) {
			Date d1 = new Date();
			System.out.println(d1);
			System.out.println("Could not find the locator for the table");
			driver.quit();
		}
		
		try {
			String text = table.findElement(By.xpath("//td[contains(text(),'Raj')]//following-sibling::td[1]")).getText();
			System.out.println(text);
			
			table.findElement(By.xpath("//td[contains(text(),'Raj')]//following-sibling::td//child::input")).click();
			
		} catch (Exception e) {
			System.out.println("Could not find the locator for the row and data");
		}
		
		Thread.sleep(5000);
		
		
		
		
		
		

}
}