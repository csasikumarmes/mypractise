package org.test.divya;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCase {
	
	
	@Test()
	public void tc01() {
		Assert.assertEquals(true, false, "Verification tc01 failed");
		System.out.println("Verification tc01 pass");

	}

	
	@Test()
	public void tc02() {
		Assert.assertEquals(true, true, "Verification tc02 failed");
		System.out.println("Verification tc02 pass");

	}
}
