package org.test.ng;

import org.testng.annotations.Test;

public class TestNGBasics2 {
	
	
	@Test(enabled = false)
	public void test1() {
		System.out.println("test 1 completed");
	}
	
	
	@Test(invocationCount = 3, dependsOnMethods = "test3")
	public void test2() {
		System.out.println("test 2 completed");
	}
	
	
	@Test()
	public void test3() {
		System.out.println("test 3 completed");
	}

}
