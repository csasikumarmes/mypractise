package org.test.ng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNGBasics2 {
	
	
	@Test(enabled = false)
	public void test1() {
		System.out.println("test 1 completed");
	}
	
	
	@Test(invocationCount = 3, dependsOnMethods = "test3")
	public void test2() {
		System.out.println("test 2 completed");
	}
	
	
	@Test()
	public void test3() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		Thread.sleep(2000);
		driver.quit();
		System.out.println("test 3 completed");
	}

}
