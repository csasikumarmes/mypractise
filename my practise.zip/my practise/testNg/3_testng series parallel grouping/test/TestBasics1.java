package org.test;

import org.testng.annotations.Test;

public class TestBasics1 {
	
	@Test(groups = {"smoke", "daily"})
	public void test01() {
		System.out.println("Test 01");

	}
	
	
	@Test(groups = {"sanity", "daily"})
	public void test02() {
		System.out.println("Test 02");

	}
	
	
	@Test(groups = {"reg","daily"})
	public void test03() {
		System.out.println("Test 03");

	}
	
	
	@Test(groups = {"reg","daily"})
	public void test04() {
		System.out.println("Test 04");

	}
	
	
	@Test(groups = {"reg","daily"})
	public void test05() {
		System.out.println("Test 05");

	}
	
	
	
	@Test(groups = {"reg","daily"})
	public void test06() {
		System.out.println("Test 06");

	}
	
	
	@Test(groups = {"reg","daily"})
	public void test07() {
		System.out.println("Test 07");

	}
	
	
	@Test(groups = {"reg","daily"})
	public void test08() {
		System.out.println("Test 08");

	}
}
