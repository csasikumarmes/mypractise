package org.test;

import org.testng.annotations.Test;

public class TestTest3 {
	
	@Test
	public void test02() {
	System.out.println(" Class test Test 3");

	}

}
