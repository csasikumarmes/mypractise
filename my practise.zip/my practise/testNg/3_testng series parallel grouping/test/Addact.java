package org.test;

import org.base.BaseClass;
import org.testng.annotations.Test;

public class Addact extends BaseClass{
	
	@Test
	public void test01() throws Exception {
		urlLaunch(excelRead(1, 0));
		maximize();
		Thread.sleep(3000);
		findElement("//input[@id='username']");
		sendkey(excelRead(1, 1));
		Thread.sleep(2000);
		findElement("//input[@id='password']");
		sendkey(excelRead(1, 2));
		Thread.sleep(2000);
		findElement("//input[@id='login']");
		click();
			}
	
	@Test
	public void test02() throws Exception {
		Thread.sleep(2000);
		findElement("//select[@id='location']");
		selectvisibleText(excelRead(1, 7));
		findElement("//input[@id='datepick_in']");
		clear();
		sendkey(excelRead(1, 4));

	}

}
