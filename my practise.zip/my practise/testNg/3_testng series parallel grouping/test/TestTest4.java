package org.test;

import org.testng.annotations.Test;

public class TestTest4 {
	
	@Test
	public void test02() {
	System.out.println(" Class test Test 4");

	}

}
