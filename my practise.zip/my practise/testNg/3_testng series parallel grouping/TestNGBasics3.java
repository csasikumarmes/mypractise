package org.test.ng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNGBasics3 {
	
	
	@Test(groups = {"smoke"})
	public void test1() {
		System.out.println("test 1 completed");
	}
	
	
	@Test(groups = {"smoke", "daily"})
	public void test2() {
		System.out.println("test 2 completed");
	}
	
	
	@Test(groups = {"sanity", "daily"})
	public void test3() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		Thread.sleep(2000);
		driver.quit();
		System.out.println("test 3 completed");
	}

	
	@Test(groups = {"sanity"})
	public void test4() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		Thread.sleep(2000);
		driver.quit();
		System.out.println("test 3 completed");
	}
	
	
	@Test(groups = {"reg"})
	public void test5() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		Thread.sleep(2000);
		driver.quit();
		System.out.println("test 3 completed");
	}
}
