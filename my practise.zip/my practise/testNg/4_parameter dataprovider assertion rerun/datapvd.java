package org.test.ng;

import org.testng.annotations.DataProvider;

public class datapvd {
	@DataProvider(name="myData", indices = {0,2}, parallel=true)
	public String[][] getData() {
		String [][] a = new String [3][2];
		a[0][0]="csasikumar";
		a[0][1]="123456";
		
		
		a[1][0]="selenium";
		a[1][1]="7890";
		
		
		a[2][0]="java";
		a[2][1]="7890";
		
		
		
		return a;

	}

}
