package org.test;

import org.testng.annotations.DataProvider;

public class DataProviderTest1 {
	
	@DataProvider(name ="login", indices = {0,2}, parallel =true)
	public String[][] getdata() {
		String[][] data = new String[3][2];
		data[0][0]="sasikumarmes";
		data[0][1]="sqr403";
		
		data[1][0]="abcdefg";
		data[1][1]="sqr403";
		
		data[2][0]="123456";
		data[2][1]="sqr403";
		
		return data;
		

	}

}
