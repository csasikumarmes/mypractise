package org.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DataProviderTest {
	
	
	
	@Test(dataProvider="login", dataProviderClass= DataProviderTest1.class)
	public void FirstPage(String s1, String s2) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://adactinhotelapp.com/");
		driver.findElement(By.id("username")).sendKeys(s1);
		driver.findElement(By.id("password")).sendKeys(s2);
				Thread.sleep(2000);	
//		driver.quit();
	
                 
	System.out.println("TC01 Completed");

}

	}


