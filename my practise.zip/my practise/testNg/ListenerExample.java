package org.test;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ListenerExample implements ITestListener {

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("my Test going to execute");
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("my Test passed");
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("my Test Failed");
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("my Test Skipped");
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		System.out.println("my Test Sucess Percentage");
		
	}

	@Override
	public void onStart(ITestContext context) {
		System.out.println("my Test before everything");
		
	}

	@Override
	public void onFinish(ITestContext context) {
		System.out.println("my Test after everything");
		
	}

}
