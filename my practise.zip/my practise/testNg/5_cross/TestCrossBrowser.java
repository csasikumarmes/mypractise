package org.test.ng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestCrossBrowser {
	
	
	@Parameters({"userName", "password", "browser"})
	@Test
	public void login(String s1, String s, String browser1) {
		
		WebDriver driver = null;
		
		switch (browser1) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
			
			
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;

		default:
			
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			break;
		}
	
		driver.get("https://adactinhotelapp.com/");
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(s1);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(s);
		

	}

}
