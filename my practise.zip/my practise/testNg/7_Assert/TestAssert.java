package org.test.ng;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

public class TestAssert {
	
	@Test
	public void tc01() {
	String s = "abcde";
//	SoftAssert assert1 = new SoftAssert();
	Assert.assertEquals(s, "abcd");
	System.out.println("a");
	// test ng - Actual , Expected
	
	// junit - Expected, actual

}
	
	
	@Test
	private void tc02() {
		System.out.println("test 2");
	}

}
