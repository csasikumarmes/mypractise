package org.test;

import static org.junit.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ListenerLogic {
	
	
	@Test
	public void test1() {
		
		Assert.assertEquals("abcd", "bcd");
		System.out.println("Test Case 1 success");
	}
	
	
	@Test
	public void test2() {
		
		Assert.assertEquals("abcd", "bcd");
		System.out.println("Test Case 2 success");
	}

}
