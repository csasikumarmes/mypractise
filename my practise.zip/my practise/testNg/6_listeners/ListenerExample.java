package org.test.ng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ListenerExample {
	
	@Test
	
	public void test1() {
		Assert.assertEquals("abcdee", "abcd");
		
	}
	
	
	@Test
	
	public void test2() {
		Assert.assertEquals("abcdee", "abcdee");
	
		
	}

}
