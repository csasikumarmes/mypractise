package day2;

public class Child1 extends ParentClass {

	
	private void employeeName() {
		System.out.println("Susant");

	}
	
	@Override
	public void employeeID(int id) {
		System.out.println("6789");
		System.out.println(id);
	}
	
	public static void main(String[] args) {
		Child1 c1 = new Child1();
		c1.employeeName();
		c1.employee();
		c1.employeeID(789);

		
	}
}
