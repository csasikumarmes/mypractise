package day2;

public class AbsClass2 extends AbsClass1{

	@Override
	public void company() {
		System.out.println("Abs Class 2 from abstract method class 1");
		
	}
	
	
	public void city() {
		System.out.println("Bangalore");
	}
	
	
	public static void main(String[] args) {
		AbsClass2 ab = new AbsClass2();
		ab.employee();
		ab.company();
		ab.city();
	
	
	
	}
	
	
	

}
