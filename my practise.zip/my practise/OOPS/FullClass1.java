package day2;

public interface FullClass1 {
	
	void employee();
	
	void company();

}
