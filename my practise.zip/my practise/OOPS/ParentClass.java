package day2;

public interface ParentClass {
	
	
		
	public void employeeID(int id);

}
