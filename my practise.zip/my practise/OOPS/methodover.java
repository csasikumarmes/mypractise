package day2;

public class methodover {
	
	public void employee() {
		System.out.println("Employee Details");
	}
	
	public void employee(String name) {
		System.out.println("Employee Name - "+name);
	}
	
	
	public void employee(int id) {
		System.out.println("ID -"+id);
	}
	
	public void employee(String addline1, String line2) {
		System.out.println(addline1);
		System.out.println(line2);
	}
	
	public void employee(String city, String state, int pincode) {
		System.out.println(city);		
		System.out.println(state);
		System.out.println(pincode);
	}
	
	
	public static void main(String[] args) {
		methodover m = new  methodover();
		m.employee();
		m.employee("Susant");
		m.employee(12345);
		m.employee("15", "Outer Ring Road");
		m.employee("Bangalore", "Karnataka", 800123);
	}
	
	
	
	

}
