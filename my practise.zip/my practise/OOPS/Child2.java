package day2;

public class Child2 extends ParentClass{
	
	public void company() {
		System.out.println("Company");

	}
	
	public static void main(String[] args) {
		Child2 c2 = new Child2();
		c2.company();
		c2.employee();
		c2.employeeID();
	}

}
