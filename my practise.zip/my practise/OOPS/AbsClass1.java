package day2;

public abstract class AbsClass1 {
	
	
	
	// non abstract method
	
	public void employee() {
		System.out.println("Non Anstract Method - AbsClass1");
	}
	
	
	// Abstract Method
	
	
	public abstract void company();
	
	

}
