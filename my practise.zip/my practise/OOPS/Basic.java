package seleniumlabs.basic;

public class Day1_Basic {
	
	private void employee() {
		System.out.println("Susant");
		System.out.println("Sasikumar");
		System.out.println("Labs");
		
	}
	
	private void empID() {
		System.out.println("12345");
	}
	
	
		
	public static void main(String[] args) {
		Day1_Basic a = new Day1_Basic();
		a.employee();
		a.empID();
	}

}
