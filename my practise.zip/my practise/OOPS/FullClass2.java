package day2;

public class FullClass2 implements FullClass1 Parent {

	@Override
	public void employee() {
		System.out.println("Employee Details");
		
	}

	@Override
	public void company() {
		System.out.println("Company Details");
		
	}
	
	
	private void personal() {
	System.out.println("Persoanl Details");

	}
	
	
	public static void main(String[] args) {
		FullClass2 f2 = new FullClass2();
		f2.employee();
		f2.company();
		f2.personal();
	}

}
