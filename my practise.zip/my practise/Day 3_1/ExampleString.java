package day3;

public class ExampleString {
	
	
	public static void main(String[] args) {
		
		String s1 = "Welcome";
		System.out.println(s1);
		
		
		// to find the length of the String
		int l = s1.length();
		System.out.println(l);
		
		
		// to check whether the string is starts with particular value or not
		
		boolean b = s1.startsWith("w");
		System.out.println(b);
		
		
		boolean c = s1.startsWith("Wel");
		System.out.println(c);
		
		// to check whether the string is ends with particular value or not
		boolean d = s1.endsWith("come");
		
		System.out.println(d);
		
		
		// to convert all the values into uppercase
		
		String e = s1.toUpperCase();
		System.out.println(e);
		
		
		
		// to convert all the values into lower case
		
		String f = s1.toLowerCase();
		System.out.println(f);
		
		
		// to find the index position of particular chararcter
		int i = s1.indexOf("e");
		System.out.println(i);
		
		
		// last index
		
		
		int j = s1.lastIndexOf("e");
		System.out.println(j);
		
		
		
		int k = s1.indexOf("e",  4);
		System.out.println(k);
		
		
		// to get the particular char from starting by using index
		
		char g = s1.charAt(3);
		System.out.println(g);
		
		
		// to check whether the string is empty or not
		
		boolean h = s1.isEmpty();
		System.out.println(h);
		
		
		// to check whether particular value is present or not
		
		boolean m = s1.contains("co");
		System.out.println(m);
		
		
		String s2 = "Welcome to JAVA Class";
		
		String s3 = "Welcome";
		
		
		boolean n = s1.equals(s3);
		System.out.println(n);
		
		boolean o = s1.equalsIgnoreCase(s3);
		System.out.println(o);
		
		
		
		// to replace the value
		
		String p = s1.replace("e", "*");
		System.out.println(p);
		
		
		// to get the particular portion of the string
		String q = s2.substring(7);
		System.out.println(q);
		
		
		String r = s2.substring(0, 8);
		System.out.println(r);
		
		
		// to remove the unwanted space in the string
		
		String s = q.trim();
		System.out.println(s);
		
		
		// to join the two string
		
		
		String t = s1.concat(s2);
		System.out.println(t);
		
		
		
		int u = System.identityHashCode(s1);
		System.out.println(u);
		
		
		int v = System.identityHashCode(s3);
		System.out.println(v);
		
		
		// if (s1==s3) - it 
		
		
		
		boolean equals = s1.equals(s3);
		System.out.println(equals);
		
		
		
		
		
		
		
		
		
	}

}
