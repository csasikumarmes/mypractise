package BaseClassAPI;



import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.IOException;

import excel.BaseAPIExcel;
import io.restassured.response.Response;

public class baseclass extends BaseAPIExcel {
	
	
	
	public Response getmethod(int rowNo, int cellNo, String url) throws IOException, InterruptedException {
		
		
	Response output;	
		
	
	output = given()
		
		
		.when()
		.queryParam("id", excelRead(rowNo, cellNo))
		.get(url);
	
	return output;
		
		
		
	}

}
