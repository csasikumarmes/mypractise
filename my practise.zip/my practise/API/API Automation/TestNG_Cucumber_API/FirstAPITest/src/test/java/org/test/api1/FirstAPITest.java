package org.test.api1;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class FirstAPITest extends BaseAPIExcel{
	String url = "http://localhost:3000/employees";
	
	
//	given()
//	content type, auth, param, headers
//	
//	when()
//	http methods - get, put, post delete
//	
//	then()
//	status code validation, response
	
	
	
//@Test
		public void getUsers() throws IOException, InterruptedException {
			String idValue = excelRead(0, 1);
			
		
		given()
		
		.when()
		.queryParam("id",2)
		.get(url)
		
		
		.then()
		.statusCode(200)
		.log().all();
		
	}
	
	
	@Test
	
	private void postmethod() throws IOException, InterruptedException {
		String dataupdate = excelRead(0, 0);
		System.out.println("Post Method Data" +dataupdate);
		
		given()
		.contentType("application/json")
		.body(dataupdate)
		.post("http://localhost:3000/employees")
		
		
		.then()
//		.statusCode(200)
		.log().all();


	}
	
	


}
