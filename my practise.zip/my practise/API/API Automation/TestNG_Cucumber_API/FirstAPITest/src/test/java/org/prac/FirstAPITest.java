package org.prac;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

public class FirstAPITest {
	String url = "https://reqres.in/api/users";
	
	
//	given()
//	content type, auth, param, headers
//	
//	when()
//	http methods - get, put, post delete
//	
//	then()
//	status code validation, response
	
	
	
//	@Test
		public void getUsers() {
		
		given()
		
		.when()
		.queryParam("page", 2)
		.get(url)
		
		
		.then()
		.statusCode(200)
		.body("page", equalTo(2))
		.log().all();
		
	}
	
	
	@Test
	private void post() {
		
		
//		Map<String, String> mp = new HashMap<String, String>();
//		mp.put("first_name", "Laks");
//		mp.put("last_name", "Chinnu");
//		mp.put("email", "Chinnu@gmail.com");
		
//		System.out.println(mp);
		JSONObject mp = new JSONObject();
		mp.put("first_name", "Laks");
		mp.put("last_name", "Chinnu");
		mp.put("email", "Chinnu@gmail.com");
		
		System.out.println(mp);
		System.out.println(mp.toJSONString());
		
		given()
		.body(mp)
		.post("http://localhost:3000/employees")
		
		.then()
		
		
		.statusCode(201)
		
		.log().all();

	}
	


}
