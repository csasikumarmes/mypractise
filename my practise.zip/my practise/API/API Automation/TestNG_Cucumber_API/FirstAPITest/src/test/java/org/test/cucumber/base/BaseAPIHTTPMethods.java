package org.test.cucumber.base;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import io.restassured.response.Response;

public class BaseAPIHTTPMethods extends BaseAPIExcel {

	public Response getUsers(String url, int rowNo, int cellNo ) throws IOException, InterruptedException {
		String idValue = excelRead(rowNo, cellNo);

		Response output;

		output = given()

				.when()
				.queryParam("id",2)
				.get(url);

		return output;

	}


	public Response postmethod(String url, int rowNo, int cellNo) throws IOException, InterruptedException {
		String dataupdate = excelRead(rowNo, cellNo);
		System.out.println("Post Method Data" +dataupdate);
		Response output;

		output = given()
				.contentType("application/json")
				.body(dataupdate)
				.post(url);


		return output;




	}
	
	
	public Response postmethod2(String url, String dataupdate ) throws IOException, InterruptedException {
		
		Response output;

		output = given()
				.contentType("application/json")
				.body(dataupdate)
				.post(url);


		return output;




	}



}
