package stepdefinition;

import java.io.IOException;
import java.util.Map;

import org.test.cucumber.base.BaseAPIHTTPMethods;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

public class StepDefinition extends BaseAPIHTTPMethods{

	String url;
	String dataupdate;
	Response postResponseBody;

	@Given("Provide the endpoint URL")
	public void provide_the_endpoint_url() throws IOException, InterruptedException {

		url = excelRead(0, 0);
		System.out.println("Post Method URL -"+url);
		System.out.println("--------****-------------");	

	}

	@Given("Provide the Post method data")
	public void provide_the_post_method_data() throws IOException, InterruptedException {

		dataupdate = excelRead(0, 1);

		System.out.println("Post Method Data Body -"+dataupdate);
		System.out.println("--------****-------------");	

	}

	@Given("Run the Post Method")
	public void run_the_post_method() throws IOException, InterruptedException {

		postResponseBody = postmethod2(url, dataupdate);



	}

	@Then("Verify the Post Method data")
	public void verify_the_post_method_data() {

		Assert.assertEquals(postResponseBody.statusCode(), 201, "Status Code Failed");

		System.out.println("Status Code Passed");

		System.out.println("--------****-------------");

		// to print the response

		System.out.println(" Post Method Response Body as String" +postResponseBody.asString());

		System.out.println("--------****-------------");

		// Assertion

		Map<String, String> postResponseBodyMap = postResponseBody.jsonPath().getMap("$");


		Assert.assertEquals(postResponseBodyMap.get("last_name"), "June17");
		Assert.assertEquals(postResponseBodyMap.get("first_name"), "June17");


		System.out.println("Last Name -"+postResponseBodyMap.get("last_sname"));


		System.out.println("--------****-------------");

	}

}
