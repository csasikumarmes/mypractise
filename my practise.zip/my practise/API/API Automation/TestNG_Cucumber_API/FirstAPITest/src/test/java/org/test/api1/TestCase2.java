package org.test.api1;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.IOException;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class TestCase2 extends BaseAPIHTTPMethods {
	
	@Test
	public void Employee() throws IOException, InterruptedException {
		
		String url = excelRead(0, 0);
		System.out.println("Poast Method URL -"+url);
		
		System.out.println("--------****-------------");
		
		Response postResponseBody = postmethod(url, 0, 1);
		
		Assert.assertEquals(postResponseBody.statusCode(), 201, "Status Code Failed");
		
		System.out.println("Status Code Passed");
		
		System.out.println("--------****-------------");
		
		// to print the response
		
		System.out.println(" Post Method Response Body as String" +postResponseBody.asString());
		
		System.out.println("--------****-------------");
		
		// Assertion
		
		Map<String, String> postResponseBodyMap = postResponseBody.jsonPath().getMap("$");
		
			
		Assert.assertEquals(postResponseBodyMap.get("last_name"), "Test1");
		Assert.assertEquals(postResponseBodyMap.get("first_name"), "Test1");
		
		
		System.out.println("Last Name -"+postResponseBodyMap.get("last_name"));
		
		
		System.out.println("--------****-------------");
		
		
		
		
		
		
	}

}
