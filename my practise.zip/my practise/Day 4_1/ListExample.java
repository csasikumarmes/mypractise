package day4;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListExample {
	public static void main(String[] args) {
		// InterfaceName variableName = new ClassName();
		
		
		List<Integer> li = new LinkedList<>();
		li.add(10);	
	li.add(20);
	li.add(30);
	li.add(40);
	
	
	
	
	System.out.println(li);
	
	
	int a = li.size();
	System.out.println(a);
	
	// to add some values in the last index
	
	
	li.add(100);
	
	System.out.println(li);
	
	// to add the  values in particular postion
	
	li.add(2, 200);
	
	System.out.println(li);
	
	
	// to replace the value by using index
	
	li.set(2, 300);
	System.out.println(li);
	
	// to replace the particular value by using index
	
	li.remove(3);
	
	System.out.println(li);
	
	

	
	
	li.add(40);
	System.out.println(li);
	
	
	// to find the index postion of the particular value
	
	// first occurance
	
	int b = li.indexOf(40);
	System.out.println(b);
	
	
	// last index
	
	int c = li.lastIndexOf(40);
	System.out.println(c);
	
	
	// to get the particular value by using index
	
	Integer d = li.get(0);
	System.out.println(d);
	
	
	
	// to check whether the list is empty or not
	
	boolean e = li.isEmpty();
	System.out.println(e);
	
	
	// to clear all the values
	
//	li.clear();
//	System.out.println(li);
	
	
	// to check whether the list is empty or not
	
	boolean f = li.isEmpty();
	System.out.println(f);
	
	
	// to check whether the particular value is present or not
	
	boolean g = li.contains(20);
	System.out.println(g);
	
	
	List<Integer> li2 = new ArrayList();
	li2.add(500);
	li2.add(300);
	
	
//	to merge the two list
	
	li.addAll(li2);
	
	System.out.println(li);
	
	
	// to remove the common values in the list
	
	System.out.println(li2);
//	
//	li.removeAll(li2);
//	
//	System.out.println(li);
	
	
	// to retain the common values
//	
//	li.retainAll(li2);
//	System.out.println(li);
	
	
	
	// normal for loop
	
	
	for (int i = 0; i < li.size(); i++) {
		
		
		Integer h = li.get(i);
		System.out.println(h);
		
		
	}
	
	
	// enhanced for loop
	
	
	for (Integer x : li) {
		System.out.println(x);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
