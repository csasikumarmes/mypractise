package org.test.webtable;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebTablePractise {
	
	@Test
	public void webTable() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://letcode.in/table");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement table = driver.findElement(By.id("simpletable"));
		List<WebElement> headers = table.findElements(By.tagName("th"));
		
		for (WebElement header : headers) {
			
			String text = header.getText();
			System.out.println(text);
			
		}
		
		
		WebElement tbody = table.findElement(By.tagName("tbody"));
		List<WebElement> allRows = tbody.findElements(By.tagName("tr"));
		
		int size = allRows.size();
		System.out.println("Row size of the table - "+size);
		
		for (WebElement row : allRows) {
			String text = row.getText();
			System.out.println(text);
			
		}
		
		if (size==3) {
			System.out.println("Pass");
			
		} else {
			
			System.out.println("Fail");

		}
		
		for (WebElement rows : allRows) {
			
			List<WebElement> column = rows.findElements(By.tagName("td"));
			WebElement firstcolumn = column.get(1);
			String text = firstcolumn.getText();
			System.out.println(text);
			if (text.equals("Raj")) {
				column.get(3).findElement(By.tagName("input")).click();
				
			}
			
		}
		
//		driver.quit();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
