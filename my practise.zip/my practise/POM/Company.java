package org.test;

public class Company {
	public static void main(String[] args) {
		Employee e = new Employee();
		e.setUserID(12345);
		e.setPassword("LO^%$&*");
		
		int userID = e.getUserID();
		System.out.println(userID);
		
		
		String pass = e.getPassword();
		System.out.println(pass);
		
	}

}
