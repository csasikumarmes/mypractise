package org.test;

public class ConstructParent {
	
	public ConstructParent() {
		this(20);
		System.out.println("Non Parameterized Constructor - Construct Parent");
	}
	
	
	public ConstructParent(int id) {
		this("Sasi");
		System.out.println("Parameterized Constructor - Construct Parent Integer");
	}
	
	
	public ConstructParent(String str) {
		System.out.println("Parameterized Constructor - Construct Parent - String");
	}
	}


