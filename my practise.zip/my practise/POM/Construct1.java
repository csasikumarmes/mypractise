package org.test;

public class Construct1 extends ConstructParent{
	
	
	public Construct1()  {
		this(20);
		System.out.println("Non Parameterized Constructor - Construct 1");
	}
	
	
	public Construct1(int id) {
		this("Sasi");
		System.out.println("Parameterized Constructor - Construct 1 Integer");
	}
	
	
	public Construct1(String str) {
		super(20);
		System.out.println("Parameterized Constructor - Construct 1 - String");
	}
	
	
	
	public static void main(String[] args) {
		ConstructParent c = new ConstructParent("abc");
		Construct1 d = new Construct1("abc");
		
	}
	
	

}
